package com;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.android.treenity_java_test.R;
import com.example.treenity_java_test.adapter.TreeListAdapter;
import com.example.treenity_java_test.model.TreeModel;
import com.example.treenity_java_test.viewmodel.TreeListViewModel;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<TreeModel> treeModelList;
    private TreeListAdapter adapter;
    private TreeListViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        final TextView noResult = findViewById(R.id.noResultTree);

        LinearLayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new TreeListAdapter(this, treeModelList);
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(TreeListViewModel.class);
        viewModel.getTreeListObserver().observe(this, new Observer<List<TreeModel>>() {
            @Override
            public void onChanged(List<TreeModel> treeModels) {
                if(treeModels != null) {
                    treeModelList = treeModels;
                    adapter.setTreeList(treeModels);
                    noResult.setVisibility(View.GONE);
                } else {
                    noResult.setVisibility(View.VISIBLE);
                }
            }
        });
        viewModel.makeApiCall();
    }
}

